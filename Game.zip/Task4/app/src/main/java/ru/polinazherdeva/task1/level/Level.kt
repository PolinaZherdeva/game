package ru.polinazherdeva.task1.level

data class Level(
    val id: Int, // id уровня
    val name: String, // название уровня
    val difficulty: String // сложность
)